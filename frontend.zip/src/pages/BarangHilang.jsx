import { useState } from "react";
import { useNavigate } from "react-router-dom";
import logo from "../assets/logo.png";
import "../styles/report.css";

function BarangHilang() {
  const navigate = useNavigate();
  const [showConfirm, setShowConfirm] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [previewImage, setPreviewImage] = useState(null);
  
  // 1. Tambahkan state untuk menampung file asli yang diunggah
  const [selectedFile, setSelectedFile] = useState(null);
  const [loading, setLoading] = useState(false);

  const [form, setForm] = useState({
    nama: "",
    deskripsi: "",
    kategori: "",
    lokasi: "",
    tanggal: "",
    waktu: "",
    email: "",
  });

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const handleUpload = (e) => {
    const file = e.target.files[0];

    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      alert("Ukuran gambar maksimal 5 MB");
      return;
    }

    // 2. Simpan file biner asli ke dalam state dan buat preview-nya
    setSelectedFile(file);
    setPreviewImage(URL.createObjectURL(file));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setShowConfirm(true);
  };

  // 3. Eksekusi pengiriman data ke Backend API saat user menekan tombol 'Ya'
  const handleYes = async () => {
    setShowConfirm(false);
    setLoading(true);

    try {
      // Wajib gunakan FormData untuk request yang mengandung file upload
      const formData = new FormData();

      // Memetakan field frontend ke schema attribute Sequelize backend
      formData.append("name", form.nama);
      formData.append("description", form.deskripsi);
      formData.append("category", form.kategori);
      formData.append("location", form.lokasi);
      formData.append("lost_date", form.tanggal);
      formData.append("lost_time", form.waktu);
      formData.append("contact", form.email);

      // Jika ada file gambar yang dipilih, masukkan ke form-data
      // Key "photo_path" disesuaikan dengan penangkapan Multer di backend (misal: upload.single('photo_path'))
      if (selectedFile) {
        formData.append("photo_path", selectedFile);
      }

      // Sesuaikan URL endpoint dengan routing backend milikmu
      const response = await fetch("http://localhost:5000/api/lost-items", {
        method: "POST",
        body: formData, // Jangan gunakan JSON.stringify dan jangan set Content-Type header secara manual
      });

      const result = await response.json();

      if (response.ok && result.success) {
        setShowSuccess(true);
      } else {
        alert(result.message || "Gagal mengirimkan laporan.");
      }
    } catch (error) {
      console.error("Error submitting report:", error);
      alert("Terjadi kesalahan koneksi ke server.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="report-app">
      <div className="report-topbar">
        <div className="report-left-header">
          <button
            className="report-back"
            type="button"
            onClick={() => navigate("/dashboard")}
          >
            ←
          </button>

          <img src={logo} alt="Findora" className="report-logo" />
        </div>

        <div
          className="report-profile"
          onClick={() => navigate("/profile")}
          style={{ cursor: "pointer" }}
        >
          <div className="report-avatar">👤</div>
          <span>Reval</span>
        </div>
      </div>

      <div className="report-main">
        <h1>Laporkan Barang Hilang</h1>

        <form className="report-form-card" onSubmit={handleSubmit}>
          <p className="report-info-text">
            Lengkapi formulir dibawah ini dengan detail yang akurat untuk membantu kami mencari barang anda.
          </p>

          <div className="report-form-grid">
            <div className="report-left-form">
              <label>Nama Barang</label>
              <input
                type="text"
                name="nama"
                value={form.nama}
                onChange={handleChange}
                placeholder="Dompet"
                required
              />

              <label>Deskripsi Detail Barang</label>
              <textarea
                name="deskripsi"
                value={form.deskripsi}
                onChange={handleChange}
                placeholder="warna hitam polos, didalamnya ada KTP"
                required
              />

              <label>Kategori Barang</label>
              <select
                name="kategori"
                value={form.kategori}
                onChange={handleChange}
                required
              >
                <option value="" disabled>
                  Pilih
                </option>
                <option>Dompet</option>
                <option>Elektronik</option>
                <option>Kunci</option>
                <option>Buku</option>
                <option>Lainnya</option>
              </select>

              <label>Lokasi Terakhir Terlihat</label>
              <input
                type="text"
                name="lokasi"
                value={form.lokasi}
                onChange={handleChange}
                placeholder="lab 203 kampus 1"
                required
              />

              <button 
                className="report-submit-btn" 
                type="submit" 
                disabled={loading}
              >
                {loading ? "Mengirim..." : "Kirim Laporan"}
              </button>
            </div>

            <div className="report-right-form">
              <label>Foto Barang (opsional, sangat disarankan)</label>

              <div className="report-upload-box">
                {previewImage ? (
                  <img
                    src={previewImage}
                    alt="Preview barang"
                    className="report-preview-img"
                  />
                ) : (
                  <>
                    <div className="report-camera">📷</div>
                    <p>
                      Unggah gambar atau drag <br />
                      dan drop disini (Maks. 5 MB)
                    </p>
                  </>
                )}

                <label className="report-upload-btn">
                  Upload
                  <input
                    type="file"
                    accept="image/*"
                    className="report-file-input"
                    onChange={handleUpload}
                  />
                </label>
              </div>

              <div className="report-date-row">
                <div>
                  <label>Tanggal Kehilangan</label>
                  <input
                    type="date"
                    name="tanggal"
                    value={form.tanggal}
                    onChange={handleChange}
                    required
                  />
                </div>

                <div>
                  <label>Waktu Kehilangan</label>
                  <input
                    type="time"
                    name="waktu"
                    value={form.waktu}
                    onChange={handleChange}
                    required
                  />
                </div>
              </div>

              <label>Informasi Kontak Anda (Nama, Email)</label>
              <input
                type="email"
                name="email"
                value={form.email}
                onChange={handleChange}
                placeholder="revalno@gmail.com"
                required
              />
            </div>
          </div>
        </form>
      </div>

      {showConfirm && (
        <div className="report-modal-bg">
          <div className="report-modal report-confirm-box">
            <div className="report-warning-icon">!</div>
            <p>Yakin ingin mengirim Laporan?</p>

            <div className="report-modal-buttons">
              <button
                type="button"
                className="report-cancel-btn"
                onClick={() => setShowConfirm(false)}
                disabled={loading}
              >
                Batalkan
              </button>

              <button 
                type="button" 
                className="report-yes-btn" 
                onClick={handleYes}
                disabled={loading}
              >
                Ya
              </button>
            </div>
          </div>
        </div>
      )}

      {showSuccess && (
        <div className="report-modal-bg">
          <div className="report-modal report-success-box">
            <div className="report-success-icon">✓</div>
            <p>Laporan berhasil terkirim</p>

            <button
              type="button"
              className="report-close-btn"
              onClick={() => navigate("/dashboard")}
            >
              Tutup
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default BarangHilang;