import "../styles/login.css";
import bg from "../assets/ith_bg.jpg";
import logo from "../assets/logo.png";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import api from "../utils/axiosConfig";

function LoginPage() {
  const navigate = useNavigate();
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault(); 
    setError('');

    // Validasi dasar di sisi Client (Frontend)
    if (!email) {
      setError('Email wajib diisi');
      return;
    }
    if (!email.includes('@')) {
      setError('Format email tidak valid');
      return;
    }
    if (!password) {
      setError('Password wajib diisi');
      return;
    }
    if (password.length < 8) {
      setError('Password minimal 8 karakter');
      return;
    }

    try {
        const response = await api.post(
        '/api/login',
        {
          email,
          password
        }
      );

      const data = response.data;

        if (response.status === 200) {
            alert(data.message || "Login Berhasil!");
            localStorage.setItem('token', data.token);
            navigate('/dashboard');
        } else {
            // Jika statusnya 401 atau berkode gagal, dan backend mengirim pesan kesalahan, tampilkan di sini.
            // Kita beri fallback teks jika data.message kosong dari backend.
            setError(data.message || 'Email atau kata sandi yang Anda masukkan salah.');
        }
    } catch (error) {
        setError('Gagal terhubung ke server. Pastikan backend menyala.');
    }
  };

  return (
    <div className="login-container">
      <div className="left">
        <h1>
          Selamat Datang di <br />
          Portal Lost & Found <br />
          Kampus ITH
        </h1>
        <p>Temukan barang berharga anda yang hilang dengan cepat dan aman</p>
      </div>

      <div
        className="right"
        style={{
          backgroundImage: `url(${bg})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <div className="overlay">
          <form className="login-card" onSubmit={handleSubmit}>

            <img src={logo} alt="logo" className="logo" />
            <h2>Masuk ke Akun Anda</h2>

            <label>Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="contoh@gmail.com"
            />

            <label>Kata Sandi</label>
            <div className="password-field">
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="******"
              />
            </div>

            {/* Menampilkan pesan kesalahan kredensial salah atau gangguan server */}
            {error && (
              <div className="register-error-message">
                <span className="error-icon">⚠️</span>
                <span className="error-text">{error}</span>
              </div>
            )}

            <button type="submit" className="login-btn">
              MASUK
            </button>

            <p className="register-text">
              Belum punya akun?{" "}
              <span onClick={() => navigate("/register")}>
                Daftar Sekarang
              </span>
            </p>
          </form>
        </div>
      </div>
    </div>
  );
}

export default LoginPage;