import "../styles/profile.css";
import logo from "../assets/logo.png";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

function ProfilePage() {
  const navigate = useNavigate();

  const [activeTab, setActiveTab] = useState("ditemukan");
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const [profileImage, setProfileImage] = useState(null);

  const handlePhotoChange = (e) => {
    const file = e.target.files[0];

    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      alert("Ukuran foto maksimal 5 MB");
      return;
    }

    setProfileImage(URL.createObjectURL(file));
  };

  const lostReports = [
    {
      id: "004",
      name: "Dompet Hitam",
      status: "Hilang",
      date: "02 Maret 2026",
    },
  ];

  const foundReports = [
    {
      id: "001",
      name: "Kunci Motor Honda",
      status: "KLAIM BERHASIL",
      date: "28 Maret 2026",
    },
    {
      id: "002",
      name: "Tumbler",
      status: "DIAMANKAN",
      date: "31 Maret 2026",
    },
  ];

  const reports = activeTab === "hilang" ? lostReports : foundReports;

  return (
    <div className="profile-page">
      <div className="profile-topbar">
        <div className="topbar-left" onClick={() => navigate("/dashboard")}>
          <span className="back-arrow">←</span>
          <img src={logo} alt="Findora Logo" />
        </div>

        <div className="topbar-user">
          <span className="mini-user">👤</span>
          <span>Reval</span>
        </div>
      </div>

      <h1 className="profile-title">Profil Saya</h1>

      <div className="profile-layout">
        <div className="profile-card">
          <div className="big-avatar">
            {profileImage ? (
              <img src={profileImage} alt="Foto Profil" className="avatar-img" />
            ) : (
              <span>👤</span>
            )}
          </div>

          <label className="photo-btn">
            📷 Sunting Foto
            <input
              type="file"
              accept="image/*"
              className="photo-input"
              onChange={handlePhotoChange}
            />
          </label>

          <label>Nama Lengkap</label>
          <input type="text" defaultValue="Revalno Charualo" />

          <label>Email</label>
          <input type="email" defaultValue="revalno@gmail.com" />

          <label>NIM/NIP</label>
          <input type="text" defaultValue="231011999" />

          <div className="profile-actions">
            <button className="save-btn" type="button">
              Simpan
            </button>

            <button
              className="logout-btn"
              type="button"
              onClick={() => setShowLogoutConfirm(true)}
            >
              Keluar
            </button>
          </div>
        </div>

        <div className="activity-card">
          <h2>Aktivitas Saya</h2>

          <div className="tabs">
            <button
              className={activeTab === "hilang" ? "active" : ""}
              type="button"
              onClick={() => setActiveTab("hilang")}
            >
              Laporan Hilang
            </button>

            <button
              className={activeTab === "ditemukan" ? "active" : ""}
              type="button"
              onClick={() => setActiveTab("ditemukan")}
            >
              Laporan Ditemukan
            </button>
          </div>

          {reports.map((item) => (
            <div className="report-box" key={item.id}>
              <div>
                <h3>Laporan #{item.id}:</h3>
                <p>{item.name}</p>

                <p>
                  Status :{" "}
                  <span
                    className={
                      item.status === "KLAIM BERHASIL"
                        ? "status claim"
                        : item.status === "DIAMANKAN"
                        ? "status secured"
                        : "status lost"
                    }
                  >
                    {item.status}
                  </span>
                </p>

                <p>Tanggal : {item.date}</p>
              </div>

              <button className="detail-btn" type="button">
                Lihat Detail
              </button>
            </div>
          ))}
        </div>
      </div>

      {showLogoutConfirm && (
        <div className="profile-modal-bg">
          <div className="logout-modal">
            <div className="warning-circle">!</div>

            <p>Apakah anda yakin ingin Log out?</p>

            <div className="modal-actions">
              <button
                className="cancel-modal"
                type="button"
                onClick={() => setShowLogoutConfirm(false)}
              >
                Batalkan
              </button>

              <button
                className="yes-modal"
                type="button"
                onClick={() => navigate("/login")}
              >
                Ya
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default ProfilePage;