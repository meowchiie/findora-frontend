import "../styles/dashboard.css";
import logo from "../assets/logo.png";
import { useNavigate } from "react-router-dom";
import { useState } from "react";

function DashboardUser() {
  const navigate = useNavigate();

  const [selectedReport, setSelectedReport] = useState(null);

  const reports = [
    {
      id: 1,
      type: "hilang",
      name: "Dompet Hitam",
      image: "👜",
      status: "Belum Ditemukan",
      category: "Dompet",
      description:
        "Dompet hitam polos berisi KTP, ATM, dan kartu mahasiswa.",
      location: "Kampus 1",
      date: "02 Maret 2026",
      time: "13:20",
      contact: "reval@gmail.com",
    },

    {
      id: 2,
      type: "hilang",
      name: "HP iPhone",
      image: "📱",
      status: "Ada Penemu",
      category: "Elektronik",
      description:
        "iPhone warna hitam dengan casing biru dan wallpaper anime.",
      location: "Kampus 1",
      date: "01 Maret 2026",
      time: "09:15",
      contact: "iphone@gmail.com",
    },

    {
      id: 3,
      type: "ditemukan",
      name: "Kunci Motor",
      image: "🔑",
      status: "Tersedia",
      category: "Kunci",
      description:
        "Kunci motor Honda dengan gantungan merah ditemukan di parkiran.",
      location: "Kampus 2",
      date: "01 April 2026",
      time: "10:40",
      contact: "penemu@gmail.com",
    },

    {
      id: 4,
      type: "ditemukan",
      name: "Tumbler",
      image: "🥤",
      status: "Sedang Diverifikasi",
      category: "Botol Minum",
      description:
        "Tumbler putih dengan stiker anime ditemukan di kantin.",
      location: "Kampus 2",
      date: "31 Maret 2026",
      time: "11:00",
      contact: "tumbler@gmail.com",
    },

    {
      id: 5,
      type: "hilang",
      name: "Pulpen",
      image: "🖊️",
      status: "Berhasil Dikembalikan",
      category: "Alat Tulis",
      description:
        "Pulpen hitam merk Faster tertinggal di ruang kelas.",
      location: "Kampus 1",
      date: "30 Maret 2026",
      time: "08:00",
      contact: "pulpen@gmail.com",
    },
  ];

  const activities = [
    {
      title: "Laporan Kunci Hilang",
      status: "Aktif",
      time: "2 jam yang lalu",
    },

    {
      title: "Laporan Dompet Hilang",
      status: "Aktif",
      time: "16 jam yang lalu",
    },

    {
      title: "Klaim Kunci Motor",
      status: "Sedang Diverifikasi",
      time: "1 hari yang lalu",
    },

    {
      title: "Laporan Jaket Hilang",
      status: "Aktif",
      time: "2 hari yang lalu",
    },

    {
      title: "Klaim Handphone",
      status: "Sedang Diverifikasi",
      time: "2 hari yang lalu",
    },

    {
      title: "Laporan Botol Hilang",
      status: "Aktif",
      time: "2 hari yang lalu",
    },
  ];

  const getStatusClass = (status) => {
    switch (status) {
      case "Belum Ditemukan":
        return "status-blue";

      case "Ada Penemu":
        return "status-orange";

      case "Menunggu Penyerahan Barang":
        return "status-yellow";

      case "Barang Sudah Diserahkan":
        return "status-purple";

      case "Berhasil Dikembalikan":
        return "status-green";

      case "Tersedia":
        return "status-green";

      case "Sedang Diverifikasi":
        return "status-orange";

      case "Berhasil Diklaim":
        return "status-blue";

      default:
        return "status-default";
    }
  };

  return (
    <div className="dashboard-page">
      <div className="dashboard-container">

        {/* TOPBAR */}
        <div className="dashboard-topbar">

          <img
            src={logo}
            alt="Findora Logo"
            className="dashboard-logo"
          />

          <div className="search-box">
            <input type="text" placeholder="Search" />
            <span>⌕</span>
          </div>

          <div
            className="dashboard-profile"
            onClick={() => navigate("/profile")}
          >
            <div className="dashboard-avatar">👤</div>
            <span>Reval</span>
          </div>

        </div>

        {/* MAIN */}
        <div className="dashboard-main">

          {/* WELCOME */}
          <section className="welcome-section">

            <h1>Selamat Datang, Reval!</h1>

            <p>
              Temukan barang anda atau bantu sesama hari ini.
            </p>

            <div className="dashboard-actions">

              <button
                className="lost-btn"
                onClick={() => navigate("/lapor-hilang")}
              >
                ⊕ Laporkan Barang Hilang
              </button>

              <button
                className="found-btn-dashboard"
                onClick={() => navigate("/lapor-ditemukan")}
              >
                ⊕ Laporkan Barang Ditemukan
              </button>

            </div>
          </section>

          <div className="dashboard-grid">

            {/* LEFT SIDE */}
            <div className="dashboard-left">

              {/* LAPORAN TERBARU */}
              <section className="latest-card">

                <div className="latest-header">

                  <h2>Laporan Terbaru</h2>

                  <button
                    onClick={() => navigate("/semua-laporan")}
                  >
                    Lihat Semua
                  </button>

                </div>

                <div className="report-list">

                  {reports.map((item) => (
                    <div
                      className="dashboard-report-card"
                      key={item.id}
                      onClick={() => setSelectedReport(item)}
                    >

                      <div className="report-image">
                        {item.image}
                      </div>

                      <h3>{item.name}</h3>

                      <p>
                        Lokasi : {item.location}
                      </p>

                      <p>
                        Tanggal : {item.date}
                      </p>

                      <span
                        className={`report-status ${getStatusClass(
                          item.status
                        )}`}
                      >
                        {item.status}
                      </span>

                    </div>
                  ))}

                </div>
              </section>

              {/* STATISTIK */}
              <section className="stats-card">

                <h2>Statistik Minggu Ini</h2>

                <div className="stats-row">

                  <div className="stat-item">
                    <h3>4</h3>
                    <p>Total Laporan Hilang</p>
                  </div>

                  <div className="divider"></div>

                  <div className="stat-item">
                    <h3>2</h3>
                    <p>Total Barang Ditemukan</p>
                  </div>

                  <div className="divider"></div>

                  <div className="stat-item">
                    <h3>2</h3>
                    <p>Klaim Berhasil</p>
                  </div>

                </div>
              </section>

            </div>

            {/* AKTIVITAS */}
            <aside className="activity-panel">

              <h2>Aktivitas</h2>

              {activities.map((item, index) => (
                <div className="activity-row" key={index}>

                  <div className="activity-avatar">
                    👤
                  </div>

                  <div>

                    <h3>{item.title}</h3>

                    <p>{item.status}</p>

                    <small>{item.time}</small>

                  </div>
                </div>
              ))}

            </aside>
          </div>
        </div>
      </div>

      {/* DETAIL MODAL */}
      {selectedReport && (
        <div className="detail-modal-bg">

          <div className="detail-modal">

            <button
              className="close-detail"
              onClick={() => setSelectedReport(null)}
            >
              ✕
            </button>

            <div className="detail-image">
              {selectedReport.image}
            </div>

            <h2>{selectedReport.name}</h2>

            <div
              className={`detail-status ${getStatusClass(
                selectedReport.status
              )}`}
            >
              {selectedReport.status}
            </div>

            <div className="detail-info">

              <p>
                <strong>Kategori:</strong>{" "}
                {selectedReport.category}
              </p>

              <p>
                <strong>Deskripsi:</strong>{" "}
                {selectedReport.description}
              </p>

              <p>
                <strong>Lokasi:</strong>{" "}
                {selectedReport.location}
              </p>

              <p>
                <strong>Tanggal:</strong>{" "}
                {selectedReport.date}
              </p>

              <p>
                <strong>Waktu:</strong>{" "}
                {selectedReport.time}
              </p>

              <p>
                <strong>Kontak:</strong>{" "}
                {selectedReport.contact}
              </p>

            </div>

            {/* ACTION BUTTON */}
            {selectedReport.type === "hilang" &&
              selectedReport.status === "Belum Ditemukan" && (
                <button className="detail-action-btn">
                  Saya Menemukan Barang Ini
                </button>
              )}

            {selectedReport.type === "ditemukan" &&
              selectedReport.status === "Tersedia" && (
                <button className="detail-action-btn">
                  Klaim Barang
                </button>
              )}

          </div>
        </div>
      )}
    </div>
  );
}

export default DashboardUser;