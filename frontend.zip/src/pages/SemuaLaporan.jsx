import "../styles/semualaporan.css";
import { useNavigate } from "react-router-dom";
import { useState } from "react";

function SemuaLaporan() {
  const navigate = useNavigate();

  const reports = [
    {
      id: 1,
      name: "Dompet Hitam",
      image: "👜",
      status: "Hilang",
      progress: "Belum Ditemukan",
      category: "Dompet",
      description:
        "Dompet kulit warna hitam polos, terdapat KTP dan kartu mahasiswa.",
      location: "Kampus 1",
      date: "02 Maret 2026",
      time: "13:20",
      contact: "reval@gmail.com",
    },

    {
      id: 2,
      name: "HP iPhone",
      image: "📱",
      status: "Hilang",
      progress: "Ada Penemu",
      category: "Elektronik",
      description:
        "iPhone warna silver dengan casing bening.",
      location: "Kampus 1",
      date: "01 Maret 2026",
      time: "10:45",
      contact: "iphone@gmail.com",
    },

    {
      id: 3,
      name: "Kunci Motor",
      image: "🔑",
      status: "Ditemukan",
      progress: "Tersedia",
      category: "Kunci",
      description:
        "Kunci motor dengan gantungan warna merah.",
      location: "Kampus 2",
      date: "01 April 2026",
      time: "09:15",
      contact: "penemu@gmail.com",
    },

    {
      id: 4,
      name: "Tumbler",
      image: "🥤",
      status: "Ditemukan",
      progress: "Sedang Diverifikasi",
      category: "Botol Minum",
      description:
        "Tumbler stainless warna biru.",
      location: "Kampus 2",
      date: "31 Maret 2026",
      time: "08:10",
      contact: "tumbler@gmail.com",
    },

    {
      id: 5,
      name: "Pulpen",
      image: "🖊️",
      status: "Hilang",
      progress: "Menunggu Penyerahan Barang",
      category: "Alat Tulis",
      description:
        "Pulpen hitam dengan tulisan FINDORA.",
      location: "Kampus 1",
      date: "30 Maret 2026",
      time: "11:00",
      contact: "pulpen@gmail.com",
    },

    {
      id: 6,
      name: "Jaket Hitam",
      image: "🧥",
      status: "Ditemukan",
      progress: "Berhasil Diklaim",
      category: "Pakaian",
      description:
        "Jaket hoodie hitam polos ukuran L.",
      location: "Perpustakaan",
      date: "29 Maret 2026",
      time: "15:00",
      contact: "jaket@gmail.com",
    },
  ];

  const [filter, setFilter] = useState("Semua");
  const [selectedItem, setSelectedItem] = useState(null);

  const filteredReports =
    filter === "Semua"
      ? reports
      : reports.filter((item) => item.status === filter);

  return (
    <div className="semua-page">

      {/* TOPBAR */}
      <div className="semua-topbar">

        <button
          className="semua-back-btn"
          onClick={() => navigate("/dashboard")}
        >
          ← Kembali
        </button>

        <h1>Semua Laporan</h1>

      </div>

      {/* FILTER */}
      <div className="semua-filter">

        <button
          className={filter === "Semua" ? "active-filter" : ""}
          onClick={() => setFilter("Semua")}
        >
          Semua Status
        </button>

        <button
          className={filter === "Hilang" ? "active-filter" : ""}
          onClick={() => setFilter("Hilang")}
        >
          Hilang
        </button>

        <button
          className={filter === "Ditemukan" ? "active-filter" : ""}
          onClick={() => setFilter("Ditemukan")}
        >
          Ditemukan
        </button>

      </div>

      {/* CARD LIST */}
      <div className="semua-grid">

        {filteredReports.map((item) => (
          <div
            className="semua-card"
            key={item.id}
            onClick={() => setSelectedItem(item)}
          >

            <div className="semua-image">
              {item.image}
            </div>

            <h2>{item.name}</h2>

            <p>
              <strong>Kategori:</strong>{" "}
              {item.category}
            </p>

            <p>
              <strong>Lokasi:</strong>{" "}
              {item.location}
            </p>

            <p>
              <strong>Tanggal:</strong>{" "}
              {item.date}
            </p>

            <span
              className={
                item.status === "Hilang"
                  ? "semua-status hilang"
                  : "semua-status ditemukan"
              }
            >
              {item.status}
            </span>

            <div className="progress-status">
              {item.progress}
            </div>

          </div>
        ))}

      </div>

      {/* MODAL DETAIL */}
      {selectedItem && (
        <div className="detail-modal-bg">

          <div className="detail-modal">

            <button
              className="close-detail"
              onClick={() => setSelectedItem(null)}
            >
              ✕
            </button>

            <div className="detail-image">
              {selectedItem.image}
            </div>

            <h2>{selectedItem.name}</h2>

            <div className="detail-info">

              <p>
                <strong>Status:</strong>{" "}
                {selectedItem.status}
              </p>

              <p>
                <strong>Progress:</strong>{" "}
                {selectedItem.progress}
              </p>

              <p>
                <strong>Kategori:</strong>{" "}
                {selectedItem.category}
              </p>

              <p>
                <strong>Lokasi:</strong>{" "}
                {selectedItem.location}
              </p>

              <p>
                <strong>Tanggal:</strong>{" "}
                {selectedItem.date}
              </p>

              <p>
                <strong>Waktu:</strong>{" "}
                {selectedItem.time}
              </p>

              <p>
                <strong>Deskripsi:</strong>{" "}
                {selectedItem.description}
              </p>

              <p>
                <strong>Kontak:</strong>{" "}
                {selectedItem.contact}
              </p>

            </div>

            {/* BUTTON ACTION */}
            {selectedItem.status === "Hilang" ? (
              <button className="detail-action-btn found-action">
                Saya Menemukan Barang Ini
              </button>
            ) : (
              <button className="detail-action-btn claim-action">
                Klaim Barang
              </button>
            )}

          </div>
        </div>
      )}

    </div>
  );
}

export default SemuaLaporan;